import React, { useState } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import { Link } from 'react-router-dom';

const RegisterForm = () => {
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: ''
  });

  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // prevent page reload
    try {
      await axios.post('http://127.0.0.1:8000/api/register/', form);
      setMessage('Registration Successful');
    } catch (error) {
      const errorMsg = error.response?.data?.username?.[0] || error.message;
      setMessage('Registration Failed: ' + errorMsg);
    }
  };

  return (

    <div>
      <Navbar/>
    <div className="MainDiv">
      <form onSubmit={handleSubmit} className="RegisterForm">
         {message && (
    <div
      className={`form-message ${
        message.startsWith('Registration Successful') ? 'success' : 'error'
      }`}
    >
      {message}
    </div>
  )}
        <label className="username-label">UserName</label>
        <input
          type="text"
          name="username"
          className="register-username-input"
          value={form.username}
          onChange={handleChange}
        />

        <label className="email-label">Email</label>
        <input
          type="text"
          name="email"
          className="register-email-input"
          value={form.email}
          onChange={handleChange}
        />

        <label className="password-label">Password</label>
        <input
          type="password"
          name="password"
          className="register-password-input"
          value={form.password}
          onChange={handleChange}
        />

        <button type="submit" className="registerformbtn">
          Register
        </button>
         <p className="register-text">
  Already I have an Account
  <Link to='/Login' className='Registerbutton-in-loginform'>
    LOGIN
  </Link></p>
      </form>
     



      </div>
    </div>
  );
};

export default RegisterForm;
