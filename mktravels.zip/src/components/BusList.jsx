import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';






const BusList = ({username, userId, onLogout }) => {
  const [buses, setBuses] = useState([]);
  const [filteredBuses, setFilteredBuses] = useState([]);
  const [filters, setFilters] = useState({ origin: '', destination: '', date: '' });
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  // Fetch user info and all buses
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/api/users/${userId}/`);
        setUser(response.data);
      } catch (err) {
        console.error("Error fetching user:", err);
      }
    };

    const fetchBuses = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/buses/");
        setBuses(response.data);
        setFilteredBuses(response.data);
      } catch (error) {
        console.log("ERROR IN FETCHING BUSES DATA", error);
      }
    };

    fetchUser();
    fetchBuses();
  }, [userId]);

  // Filter buses
  const applyFilters = () => {
    const filtered = buses.filter(bus =>
      bus.origin.toLowerCase().includes(filters.origin.toLowerCase()) &&
      bus.destination.toLowerCase().includes(filters.destination.toLowerCase()) &&
      (!filters.date || bus.date === filters.date)
    );
    setFilteredBuses(filtered);
  };

  const handleChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleViewSeats = (id) => {
    navigate(`/bus/${id}`);
  };

  const handleLogoutClick = () => {
    onLogout();
    navigate('/login');
  };


  const SeatsHistory=()=>{
    navigate('/UserBookings')
  }

  return (
    <div className="buslist-container">
      <header className="buslist-header">
        <div className="user-info">
          <FontAwesomeIcon icon={faUserCircle} className="user-icon" />
            &nbsp;
          <span>Welcome, {username || 'User'}!</span>
          
        </div>
        <button onClick={SeatsHistory} className='my-bookings-button'>MY BOOKINGS</button>
        <button className="logout-btn" onClick={handleLogoutClick}>Logout</button>
        
      </header>

      <div className="filters">
        <input name="origin" placeholder="Origin" value={filters.origin} onChange={handleChange} />
        <input name="destination" placeholder="Destination" value={filters.destination} onChange={handleChange} />
        <input type="date" name="date" value={filters.date} onChange={handleChange} />
        <button onClick={applyFilters}>Search</button>
      </div>

      <div className="bus-cards">
        {filteredBuses.length === 0 ? (
          <p>No buses found.</p>
        ) : (
          filteredBuses.map(bus => (
            <div className="bus-card" key={bus.id}>
              <h2>{bus.bus_name} (No:{bus.number})</h2>
              <p><strong>From:</strong> {bus.origin}</p>
              <p><strong>To:</strong> {bus.destination}</p>
              <p><strong>Date:</strong> {bus.date}</p>
              <p><strong>Time:</strong> {bus.start_time} - {bus.reach_time}</p>
              <p><strong>Price:</strong> ₹{bus.price}</p>
              <button onClick={() => handleViewSeats(bus.id)}>View Seats</button>
            </div>
          ))
        )}
      </div>
      {/* Footer */}
      <footer className="footer">
        <p>© {new Date().getFullYear()} MK Travels. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default BusList;
