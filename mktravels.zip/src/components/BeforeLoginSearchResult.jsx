import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';


const BeforeLoginSearchResult = () => {
  const [buses, setBuses] = useState([]);
  const [filteredBuses, setFilteredBuses] = useState([]);
  const [filters, setFilters] = useState({ from: '', to: '', date: '' });
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/buses/')
      .then(response => setBuses(response.data))
      .catch(error => console.error('Failed to fetch buses:', error));
  }, []);

  const handleChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleSearch = () => {
    const { from, to, date } = filters;
    const filtered = buses.filter(bus =>
      bus.from.toLowerCase().includes(from.toLowerCase()) &&
      bus.to.toLowerCase().includes(to.toLowerCase()) &&
      bus.date === date
    );
    setFilteredBuses(filtered);
  };

  const handleBook = () => {
    alert('Please login to book your ticket.');
    navigate('/login');
  };

  return (
    <div>
      <Navbar />
      <div className="page-container">
        <h2 className="page-title">Search Buses</h2>
        <div className="filters">
          <input
            type="text"
            name="from"
            placeholder="From"
            value={filters.from}
            onChange={handleChange}
          />
          <input
            type="text"
            name="to"
            placeholder="To"
            value={filters.to}
            onChange={handleChange}
          />
          <input
            type="date"
            name="date"
            value={filters.date}
            onChange={handleChange}
          />
        </div>
        <button onClick={handleSearch} className="search-btn">Search</button>

        <div className="results-section">
          <h3 className="result-title">Available Buses</h3>
          {filteredBuses.length === 0 ? (
            <p className="no-results">No buses found.</p>
          ) : (
            <ul className="bus-list">
              {filteredBuses.map(bus => (
                <li key={bus.id} className="bus-card">
                  <p><strong>From:</strong> {bus.from}</p>
                  <p><strong>To:</strong> {bus.to}</p>
                  <p><strong>Date:</strong> {bus.date}</p>
                  <p><strong>Time:</strong> {bus.time}</p>
                  <p><strong>Price:</strong> Rs. {bus.price}</p>
                  <button onClick={handleBook} className="book-btn">Book Now</button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};

export default BeforeLoginSearchResult;
