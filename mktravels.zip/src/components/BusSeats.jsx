import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';


const BusSeats = () => {
  const [bus, setBus] = useState(null);
  const [seats, setSeats] = useState([]);
  const [selectedSeat, setSelectedSeat] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const { busId } = useParams();

  useEffect(() => {
    const fetchBusDetails = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/api/buses/${busId}`);
        setBus(response.data);
        setSeats(response.data.seats || []);
      } catch (error) {
        console.log('ERROR IN FETCHING SEAT DETAILS', error);
      }
    };
    fetchBusDetails();
  }, [busId]);

  const chunkSeats = (seatList, size = 4) => {
    const result = [];
    for (let i = 0; i < seatList.length; i += size) {
      result.push(seatList.slice(i, i + size));
    }
    return result;
  };

  const handleSeatClick = (seat) => {
    setSelectedSeat(seat);
    setShowPopup(true);
  };

  const bookSeat = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `http://127.0.0.1:8000/api/book-seat/${selectedSeat.id}/`,
        {},
        { headers: { Authorization: `Token ${token}` } }
      );
      const updatedSeats = seats.map(seat =>
        seat.id === selectedSeat.id ? { ...seat, is_booked: true } : seat
      );
      setSeats(updatedSeats);
      setShowPopup(false);
    } catch (error) {
      alert('Booking failed');
    }
  };

  return (
    <div>
      {bus && (
        <div className="busdetailsinbusseats">
          <h2 className="busnameinbusseats">
            {bus.bus_name} (Bus No: {bus.number})
          </h2>
          <p><strong>From:</strong> {bus.origin}</p>
          <p><strong>To:</strong> {bus.destination}</p>
          <p><strong>Date:</strong> {bus.date}</p>
          <p><strong>Time:</strong> {bus.start_time} - {bus.reach_time}</p>
          <p><strong>Price:</strong> ₹{bus.price}</p>
        </div>
      )}

      <div className="seats-grid">
        {chunkSeats(seats).map((row, rowIndex) => (
          <div className="seat-row" key={rowIndex}>
            <div className="seat-pair">
              {row[0] && (
                <button
                  className={`seat-btn ${row[0].is_booked ? 'booked' : 'available'}`}
                  onClick={() => !row[0].is_booked && handleSeatClick(row[0])}
                  disabled={row[0].is_booked}
                >
                  🪑 {row[0].seat_number}
                </button>
              )}
              {row[1] && (
                <button
                  className={`seat-btn ${row[1].is_booked ? 'booked' : 'available'}`}
                  onClick={() => !row[1].is_booked && handleSeatClick(row[1])}
                  disabled={row[1].is_booked}
                >
                  🪑 {row[1].seat_number}
                </button>
              )}
            </div>

            <div className="seat-aisle" />

            <div className="seat-pair">
              {row[2] && (
                <button
                  className={`seat-btn ${row[2].is_booked ? 'booked' : 'available'}`}
                  onClick={() => !row[2].is_booked && handleSeatClick(row[2])}
                  disabled={row[2].is_booked}
                >
                  🪑 {row[2].seat_number}
                </button>
              )}
              {row[3] && (
                <button
                  className={`seat-btn ${row[3].is_booked ? 'booked' : 'available'}`}
                  onClick={() => !row[3].is_booked && handleSeatClick(row[3])}
                  disabled={row[3].is_booked}
                >
                  🪑 {row[3].seat_number}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {showPopup && (
        <div className="popup-overlay">
          <div className="popup">
            <h3>Confirm Booking</h3>
            <p>Book Seat: {selectedSeat?.seat_number}?</p>
            <button className="confirm-btn" onClick={bookSeat}>Confirm</button>
            <button className="close-btn" onClick={() => setShowPopup(false)}>Cancel</button>
          </div>
        </div>
      )}
      {/* Footer */}
      <footer className="footer">
        <p>© {new Date().getFullYear()} MK Travels. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default BusSeats;
