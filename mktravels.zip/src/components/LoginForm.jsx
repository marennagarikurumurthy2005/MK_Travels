import React, { useState } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import { useNavigate, Link } from 'react-router-dom';

const LoginForm = ({ onLogin }) => {
  const [form, setForm] = useState({ username: '', password: '' });
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const response = await axios.post('http://127.0.0.1:8000/api/login/', form);

      const { token, user_id, username } = response.data;

      localStorage.setItem('token', token);
      localStorage.setItem('userId', user_id);
      localStorage.setItem('username', username);

      setMessage('Login successful');
      onLogin(token, user_id, username); // Pass all to App
      navigate('/BusList');
    } catch (error) {
      const errorMsg = error.response?.data?.detail || 'Login failed';
      setMessage(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Navbar />
      <div className="MainDiv">
        <form onSubmit={handleSubmit} className="RegisterForm">
          {message && (
            <div className={`form-message ${message === 'Login successful' ? 'success' : 'error'}`}>
              {message}
            </div>
          )}

          <label className="username-label">Username</label>
          <input
            type="text"
            name="username"
            className="register-username-input"
            value={form.username}
            onChange={handleChange}
            required
          />

          <label className="password-label">Password</label>
          <input
            type="password"
            name="password"
            className="register-password-input"
            value={form.password}
            onChange={handleChange}
            required
          />

          <button type="submit" className="registerformbtn" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>

          <p className="register-text">
            Create New Account &nbsp;&nbsp;
            <Link to="/register" className="Registerbutton-in-loginform">
              REGISTER
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;
