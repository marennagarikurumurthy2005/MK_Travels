import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const UserBookings = ({ token, userId, username }) => {
  const [bookings, setBookings] = useState([]);
  const [bookingError, setBookingError] = useState(null);
  const [cancellingId, setCancellingId] = useState(null);

  useEffect(() => {
    fetchBookings();
  }, [userId, token]);

  const fetchBookings = async () => {
    try {
      const response = await axios.get(
        `http://127.0.0.1:8000/api/user/${userId}/bookings`,
        {
          headers: {
            Authorization: `Token ${token}`,
          },
        }
      );
      setBookings(response.data);
    } catch (error) {
      setBookingError(error.response?.data?.message || 'Error fetching bookings');
    }
  };

  const handleCancel = async (bookingId) => {
    if (!window.confirm("Are you sure you want to cancel this booking?")) return;
    try {
      setCancellingId(bookingId);
      await axios.delete(`http://127.0.0.1:8000/api/bookings/${bookingId}/cancel/`, {
        headers: {
          Authorization: `Token ${token}`,
        },
      });

      setBookings(bookings.filter((b) => b.id !== bookingId));
      toast.success('Booking cancelled successfully');
    } catch (error) {
      toast.error('Cancellation failed');
      console.error(error);
    } finally {
      setCancellingId(null);
    }
  };

  return (
    <div className="user-bookings-container">
      <h2>Bookings for {username}</h2>
      {bookingError && <p className="error-message">{bookingError}</p>}
      {bookings.length === 0 ? (
        <p>No bookings found.</p>
      ) : (
        <ul className="user-bookings-list">
          {bookings.map((booking) => (
            <li key={booking.id}>
              <div>
                <strong>Bus:</strong> {booking.bus} &nbsp; | &nbsp;
                <strong>Seat:</strong> {booking.seat} <br />
                <strong>Date:</strong> {booking.booking_time.slice(0, 10)} &nbsp; | &nbsp;
                <strong>Time:</strong> {booking.booking_time.slice(11, 19)}
              </div>
              <button
                className="cancel-booking-btn"
                onClick={() => handleCancel(booking.number)}
                disabled={cancellingId === booking.id}
              >
                {cancellingId === booking.id ? 'Cancelling...' : 'Cancel Booking'}
              </button>
            </li>
          ))}
        </ul>
      )}
      <ToastContainer position="top-right" autoClose={3000} />
      {/* Footer */}
      <footer className="footer">
        <p>© {new Date().getFullYear()} MK Travels. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default UserBookings;
