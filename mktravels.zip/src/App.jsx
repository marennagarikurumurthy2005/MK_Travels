import React, { useState } from 'react'
import RegisterForm from './components/RegisterForm';
import { Routes,Route } from 'react-router-dom';
import ProtectedRoute from './ProtectedRoute';

import './App.css';
import LoginForm from './components/LoginForm';
import LandingPage from './LandingPage';
import BeforeLoginSearchResult from './components/BeforeLoginSearchResult';
import BusList from './components/BusList';
import BusSeats from './components/BusSeats';
import UserBookings from './components/UserBookings';




const App = () => {

const [token,setToken]=useState(localStorage.getItem('token'))
const [userId,setUserId]=useState(localStorage.getItem('userId'))
const [username,setUsername] = useState(localStorage.getItem('username'))
const [selectedBusId, setSelectedBusId] = useState(null)

const handleLogin=(token,userId,username)=>{
  localStorage.setItem('token',token)
  localStorage.setItem('userId',userId)
  localStorage.setItem('username',username);
  setToken(token)
  setUserId(userId)
  setUsername(username);
}

const handleLogout = ()=>{
  localStorage.removeItem('token')
  localStorage.removeItem('userId')
  setToken(null)
  setUserId(null)
  setSelectedBusId(null)
}


  return (
    <div>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginForm onLogin={handleLogin} />} />
        <Route path="/register" element={<RegisterForm />} />


        <Route path="/BusList" element={
         <ProtectedRoute> <BusList token={token} userId={userId} username={username} onLogout={handleLogout}/> </ProtectedRoute>} />
        <Route path="/bus/:busId" element={<ProtectedRoute><BusSeats  /></ProtectedRoute>} />


          <Route path="/UserBookings" element={<ProtectedRoute> <UserBookings  token={token} userId={userId} username={username} /> </ProtectedRoute>} />




        

      </Routes>
    </div>
  )
}

export default App;