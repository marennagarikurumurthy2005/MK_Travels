import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';


const LandingPage = () => {
  const [buses, setBuses] = useState([]);
  const [filteredBuses, setFilteredBuses] = useState([]);
  const [message, setMessage] = useState('');
  const [showPopup, setShowPopup] = useState(false);
  const [searchParams, setSearchParams] = useState({
    from: '',
    to: '',
    date: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setSearchParams({ ...searchParams, [e.target.name]: e.target.value });
  };

  const searchHandler = async (e) => {
    e.preventDefault();
    setMessage('');
    setFilteredBuses([]);

    try {
      const res = await fetch('http://127.0.0.1:8000/api/buses/');
      const data = await res.json();
      setBuses(data);

      const matches = data.filter(bus =>
        bus.origin.toLowerCase() === searchParams.from.toLowerCase() &&
        bus.destination.toLowerCase() === searchParams.to.toLowerCase()
      );

      setFilteredBuses(matches);

      if (matches.length === 0) {
        setMessage('No buses available for the selected route.');
      }
    } catch (err) {
      console.error('Error fetching buses:', err);
      setMessage('Failed to fetch buses. Please try again.');
    }
  };

  const handleBookNow = () => {
    setShowPopup(true);
  };

  const closePopup = () => {
    setShowPopup(false);
  };

  const goToLogin = () => {
    navigate('/Login');
  };

  return (
    <div className="landing-wrapper">
      {/* Header */}
      <header className="header">
        <Link to='/'><h1 className="logo">MK Travels</h1></Link>
        <nav className="nav-links">
          <a href="#features">Features</a>
          <Link to='/Login'>Login</Link>
          <Link to='/Register'>Register</Link>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <div className="overlay"></div>
        <div className="hero-content">
          <h2>Book Your Bus Tickets Easily</h2>
          <p>Fast, Secure & Reliable Bus Ticket Booking Service</p>

          <form className="search-form" onSubmit={searchHandler}>
            <input type="text" name="from" value={searchParams.from} onChange={handleChange} placeholder="From" required />
            <input type="text" name="to" value={searchParams.to} onChange={handleChange} placeholder="To" required />
            <input type="date" name="date" value={searchParams.date} onChange={handleChange} required />
            <button type="submit">Search Buses</button>
          </form>

          {message && <p className="login-message">{message}</p>}

          {/* Filtered Bus List */}
          {filteredBuses.length > 0 && (
            <div className="bus-list">
              <h3>Available Buses</h3>
              {filteredBuses.map((bus, index) => (
                <div key={index} className="bus-card">
                  <p><strong>Name:</strong> {bus.bus_name}</p>
                  <p><strong>From:</strong> {bus.origin}</p>
                  <p><strong>To:</strong> {bus.destination}</p>
                  <p><strong>Departure:</strong> {bus.start_time}</p>
                  <p><strong>Price:</strong> ₹{bus.price}</p>
                  <button onClick={handleBookNow}>Book Now</button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="features">
        <h3>Why Choose Us?</h3>
        <div className="feature-grid">
          <div>
            <h4>Easy Booking</h4>
            <p>Book your tickets in just a few clicks.</p>
          </div>
          <div>
            <h4>Secure Payments</h4>
            <p>100% secure and encrypted transactions.</p>
          </div>
          <div>
            <h4>24/7 Support</h4>
            <p>We're always here to help you.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>© {new Date().getFullYear()} MK Travels. All rights reserved.</p>
      </footer>

      {/* Login Popup */}
      {showPopup && (
        <div className="popup-overlay">
          <div className="popup">
            <h3>Please login to BOOK YOUR SEAT</h3>
            <button className="login-btn" onClick={goToLogin}>Go to Login</button>
            <button className="close-btn" onClick={closePopup}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default LandingPage;
